extends Node

var dialog_box

func _ready():

	var cena = preload("res://UI/DialogBox.tscn")

	dialog_box = cena.instantiate()

	get_tree().root.add_child.call_deferred(dialog_box)

func mostrar(texto:String):
	dialog_box.mostrar(texto)

func fechar():
	dialog_box.fechar()
